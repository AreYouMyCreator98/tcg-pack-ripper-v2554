from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os, socket
os.chdir(Path(__file__).resolve().parent)
print('V261 isolated preview. On the same Wi-Fi, open http://YOUR-COMPUTER-LAN-IP:8080 on your phone.')
print('Use a separate HTTPS preview host to test install/offline PWA behavior. Ctrl+C stops this server.')
ThreadingHTTPServer(('0.0.0.0',8080),SimpleHTTPRequestHandler).serve_forever()
