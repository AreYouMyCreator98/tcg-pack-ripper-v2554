const VERSION = 'tcg-pack-ripper-preview-v261-1';
const STATIC = `${VERSION}-static`;
const MEDIA = `${VERSION}-media`;
const CORE = ["./preview-bootstrap.js",
  "./",
  "./assets/index-Cp_RjK2D.js",
  "./assets/profile-DE_hyOsV.js",
  "./assets/trade-hub-CRAdjuA-.js",
  "./assets/view-CGSc1dHz.js",
  "./index.html",
  "./manifest.webmanifest",
  "./runtime/artwork.js",
  "./runtime/binder-bridge.js",
  "./runtime/bulk-bridge.js",
  "./runtime/collector-bridge.js",
  "./runtime/core.js",
  "./runtime/hub-bridge.js",
  "./runtime/pack-bridge.js",
  "./runtime/packs.js",
  "./runtime/profile-bridge.js",
  "./runtime/profile-extras.js",
  "./runtime/progression.js",
  "./runtime/rank-frames.js",
  "./runtime/special-collection.js",
  "./runtime/supabase.js",
  "./styles/binder.css",
  "./styles/bulk.css",
  "./styles/collection.css",
  "./styles/collector-cinematics.css",
  "./styles/collector-studio.css",
  "./styles/collector-v260.css",
  "./styles/collector-v261.css",
  "./styles/core.css",
  "./styles/mobile-performance.css",
  "./styles/multiplayer.css",
  "./styles/pack-v253.css",
  "./styles/pack-v2533.css",
  "./styles/pack-v254.css",
  "./styles/packs.css",
  "./styles/profile-studio.css",
  "./styles/trade-hub.css",
  "./ui/chrome.html",
  "./ui/components/binder-shop.html",
  "./ui/components/bulk-inspect.html",
  "./ui/overlays.html",
  "./ui/screens/binder.html",
  "./ui/screens/bulk.html",
  "./ui/screens/history.html",
  "./ui/screens/marketplace.html",
  "./ui/screens/profile.html",
  "./ui/screens/rip.html",
  "./ui/screens/trade.html"
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(STATIC)
    .then(cache => Promise.allSettled(CORE.map(async url => {
      try { const r = await fetch(url, { cache: 'reload' }); if (r.ok) await cache.put(url, r); } catch (_) {}
    })))
    .then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys()
    .then(keys => Promise.all(keys.filter(k => k.startsWith('tcg-pack-ripper-preview-') && ![STATIC, MEDIA].includes(k)).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

async function cachedFallback(cache, req, url) {
  return await cache.match(req) || await cache.match(new Request(url.origin + url.pathname)) || null;
}

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  if (req.mode === 'navigate') {
    event.respondWith(fetch(req, { cache: 'no-store' }).catch(() => caches.match('./index.html')));
    return;
  }

  if (url.pathname.includes('/assets/')) {
    event.respondWith(caches.open(MEDIA).then(async cache => {
      const hit = await (await caches.open(STATIC)).match(req) || await cache.match(req);
      if (hit) return hit;
      const res = await fetch(req);
      if (res.ok) cache.put(req, res.clone());
      return res;
    }));
    return;
  }

  // Executable/UI resources are network-first. This prevents a new HTML shell
  // from being paired with stale JS/runtime chunks from an older app version.
  const liveCode = /\/(src|runtime|ui|styles)\//.test(url.pathname) || /\/(manifest\.webmanifest)$/.test(url.pathname);
  if (liveCode) {
    event.respondWith(caches.open(STATIC).then(async cache => {
      try {
        const res = await fetch(req, { cache: 'no-store' });
        if (res.ok) cache.put(req, res.clone());
        return res;
      } catch (_) {
        return await cachedFallback(cache, req, url) || Response.error();
      }
    }));
    return;
  }

  event.respondWith(caches.open(STATIC).then(async cache => {
    const hit = await cache.match(req);
    const network = fetch(req).then(res => {
      if (res.ok) cache.put(req, res.clone());
      return res;
    }).catch(() => null);
    return hit || await network || Response.error();
  }));
});
