window.TCG_PREVIEW=true;
window.TCG_CLOUD_CONFIG=Object.freeze({});
const previewFetch=window.fetch.bind(window);
window.fetch=(input,options)=>{const url=new URL(typeof input==='string'||input instanceof URL?input:input.url,location.href);if(url.hostname.endsWith('.supabase.co')&&!url.pathname.startsWith('/functions/v1/card-art-v239'))return Promise.reject(new Error('Online accounts are disabled in this isolated preview.'));return previewFetch(input,options);};
window.addEventListener('tcg:app-ready',()=>{const badge=document.querySelector('.silver-brand span');if(badge){badge.id='previewNotice';badge.textContent='V261 PREVIEW · LOCAL SAVE';badge.title='Separate local save. Online accounts disabled.';}});